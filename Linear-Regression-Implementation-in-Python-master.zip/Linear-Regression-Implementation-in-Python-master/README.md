# Machine Learning Implementations in Python

Jupyter Notebook with examples on how to implement Linear Regression in different ways with Python:

1. Manual with Gradient Descent
2. Using Scipy 
3. Using Scikit-Learn
4. Using Statsmodel
5. Using Seaborn 

